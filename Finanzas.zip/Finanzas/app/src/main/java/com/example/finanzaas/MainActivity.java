import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.finanzaas.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText etMonto, etDescripcion;
    private Button btnAgregar;
    private ListView lvGastos;
    private ArrayList<String> gastos = new ArrayList<>();
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Vincular vistas
        etMonto = findViewById(R.id.etMonto);
        etDescripcion = findViewById(R.id.etDescripcion);
        btnAgregar = findViewById(R.id.btnAgregar);
        lvGastos = findViewById(R.id.lvGastos);

        // Configurar adaptador
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, gastos);
        lvGastos.setAdapter(adapter);

        // Acción del botón
        btnAgregar.setOnClickListener(v -> agregarGasto());
    }

    private void agregarGasto() {
        String monto = etMonto.getText().toString();
        String descripcion = etDescripcion.getText().toString();

        if (monto.isEmpty() || descripcion.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        String gasto = descripcion + ": $" + monto;
        gastos.add(gasto);
        adapter.notifyDataSetChanged();

        // Limpiar campos
        etMonto.setText("");
        etDescripcion.setText("");
    }
}